package com.example.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;


import com.example.exception.ModeloNotFoundException;
import com.example.model.entities.Programador;
import com.example.service.ProgramadorService;

import io.swagger.annotations.Api;


@RestController
@RequestMapping("/programadores")
@Api(value = "Servicio REST para los programadores")
public class ProgramadorController {

	@Autowired
	private ProgramadorService programadorService;

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Programador>> listar() {
		List<Programador> programadores = new ArrayList<>();
		programadores = programadorService.listar();
		return new ResponseEntity<List<Programador>>(programadores, HttpStatus.OK);
	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<Programador> listarId(@PathVariable("id") Integer id) {
		Optional<Programador> programadores = programadorService.listId(id);
		if (!programadores.isPresent()) {
			throw new ModeloNotFoundException("ID: " + id);
		}
		return new ResponseEntity<Programador>(programadores.get(), HttpStatus.OK);

	}

	@PostMapping
	public ResponseEntity<Programador> registrar(@Valid @RequestBody Programador programador) {
		Programador programadorNew = new Programador();
		programadorNew = programadorService.registrar(programador);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(programadorNew.getId())
				.toUri();
		return ResponseEntity.created(location).build();
	}

	@PutMapping
	public ResponseEntity<Programador> actualizar(@Valid @RequestBody Programador programador) {
		programadorService.modificar(programador);
		return new ResponseEntity<Programador>(HttpStatus.OK);
	}

	
	@DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public void eliminar(@PathVariable Integer id) {
		Optional<Programador> programador = programadorService.listId(id);
		if (!programador.isPresent()) {
			throw new ModeloNotFoundException("ID: " + id);
		} else {
			programadorService.eliminar(id);
		}
	}

}
