package com.example.dto;


import java.util.List;

import com.example.model.entities.Lenguaje;
import com.example.model.entities.Preferencia;



public class DetallePreferenciaDTO {
	
	private Preferencia preferencia;
	private List<Lenguaje> lstLenguaje;
	

	public Preferencia getPreferencia() {
		return preferencia;
	}
	public void setPreferencia(Preferencia preferencia) {
		this.preferencia = preferencia;
	}
	public List<Lenguaje> getLstLenguaje() {
		return lstLenguaje;
	}
	public void setLstLenguaje(List<Lenguaje> lstLenguaje) {
		this.lstLenguaje = lstLenguaje;
	}
	

	
}
