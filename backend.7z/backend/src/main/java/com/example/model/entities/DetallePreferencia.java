package com.example.model.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(DetallePreferenciaPK.class)
@Table(name = "detalle_preferencias")
public class DetallePreferencia {
	
	@Id
	private Preferencia preferencia;
	
	@Id
	private Lenguaje lenguaje;


	public Preferencia getPreferencia() {
		return preferencia;
	}

	public void setPreferencia(Preferencia preferencia) {
		this.preferencia = preferencia;
	}

	public Lenguaje getLenguaje() {
		return lenguaje;
	}

	public void setLenguaje(Lenguaje lenguaje) {
		this.lenguaje = lenguaje;
	}
	

	
}
