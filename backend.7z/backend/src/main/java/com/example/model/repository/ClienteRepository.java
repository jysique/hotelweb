package com.example.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.model.entities.Cliente;

@Repository
public interface ClienteRepository
	extends JpaRepository<Cliente,Integer>{

	
	@Query(value = "INSERT INTO clientes(id,nombres,apellidos,dni,telefono)"
				+ "VALUES(1,Jose,Ysique,70865331,960330166)",nativeQuery = true)
	Integer registrar(@Param("1,Jose,Ysique,70865331,960330166") Integer clienteId);
	
	
}