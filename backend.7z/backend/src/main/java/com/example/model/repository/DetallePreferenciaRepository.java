package com.example.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.model.entities.DetallePreferencia;

@Repository
public interface DetallePreferenciaRepository
		extends JpaRepository<DetallePreferencia,Integer> {

	@Modifying
	@Query(value = "INSERT INTO detalle_preferencias(preferencia_id,lenguaje_id)"
				+ "VALUES(:preferenciaId,:lenguajeId)",nativeQuery = true)
	Integer registrar(@Param("preferenciaId") Integer preferenciaId,
			@Param("lenguajeId") Integer lenguajeId);
}
