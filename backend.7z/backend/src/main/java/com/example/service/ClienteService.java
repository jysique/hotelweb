package com.example.service;

import com.example.model.entities.Cliente;

public interface ClienteService extends CrudService<Cliente> {

}
