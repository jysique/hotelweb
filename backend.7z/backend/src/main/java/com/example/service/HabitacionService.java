package com.example.service;

import com.example.model.entities.Habitacion;

public interface HabitacionService extends CrudService<Habitacion>{

}
