package com.example.service;


import com.example.model.entities.Lenguaje;

public interface LenguajeService extends CrudService<Lenguaje>{

}
