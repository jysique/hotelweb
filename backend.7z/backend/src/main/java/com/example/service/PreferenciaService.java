package com.example.service;


import com.example.dto.DetallePreferenciaDTO;
import com.example.model.entities.Preferencia;


public interface PreferenciaService extends CrudService<Preferencia> {

	Preferencia registrar(DetallePreferenciaDTO preferenciaDTO);
}
