package com.example.service;

import com.example.model.entities.Programador;

public interface ProgramadorService extends CrudService<Programador> {

}
