package com.example.service;

import com.example.dto.DetalleReservaDTO;
import com.example.model.entities.Reserva;

public interface ReservaService extends CrudService<Reserva> {

	Reserva registrar(DetalleReservaDTO reservaDTO);
}
