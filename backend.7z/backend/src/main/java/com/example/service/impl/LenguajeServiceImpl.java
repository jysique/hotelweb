package com.example.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.entities.Lenguaje;
import com.example.model.repository.LenguajeRepository;
import com.example.service.LenguajeService;



@Service
public class LenguajeServiceImpl implements LenguajeService{
	
	@Autowired
	private LenguajeRepository lenguajeRepository;
	
	@Override
	public Lenguaje registrar(Lenguaje t) {
		return lenguajeRepository.save(t);
	}

	@Override
	public Lenguaje modificar(Lenguaje t) {
		// TODO Auto-generated method stub
		return lenguajeRepository.save(t);
	}

	@Override
	public void eliminar(int id) {
		lenguajeRepository.deleteById(id);
		
	}

	@Override
	public Optional<Lenguaje> listId(int id) {
		// TODO Auto-generated method stub
		return lenguajeRepository.findById(id);
	}

	@Override
	public List<Lenguaje> listar() {
		// TODO Auto-generated method stub
		return lenguajeRepository.findAll();
	}
	
}
