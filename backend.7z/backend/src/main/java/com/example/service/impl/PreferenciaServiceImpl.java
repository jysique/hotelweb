package com.example.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dto.DetallePreferenciaDTO;
import com.example.model.entities.Preferencia;
import com.example.model.repository.DetallePreferenciaRepository;
import com.example.model.repository.PreferenciaRepository;
import com.example.service.PreferenciaService;


@Service
public class PreferenciaServiceImpl implements PreferenciaService{
	
	@Autowired
	private PreferenciaRepository preferenciaRepository;
	
	@Autowired
	private DetallePreferenciaRepository detallePreferenciaRepository;
	
	
	@Override
	public Preferencia registrar(Preferencia t) {
		//if(t.getFechaEntrada().isBefore(t.getFechaSalida()) ) {
			return preferenciaRepository.save(t);
		//}else 
		//	return null;
	}

	@Override
	public Preferencia modificar(Preferencia t) {
		// TODO Auto-generated method stub
		//if(t.getFechaEntrada().isBefore(t.getFechaSalida()) ) {
			return preferenciaRepository.save(t);
		//}else 
		//	return null;
	}

	@Override
	public void eliminar(int id) {
		preferenciaRepository.deleteById(id);
		
	}

	@Override
	public Optional<Preferencia> listId(int id) {
		// TODO Auto-generated method stub
		return preferenciaRepository.findById(id);
	}

	@Override
	public List<Preferencia> listar() {
		// TODO Auto-generated method stub
		return preferenciaRepository.findAll();
	}
	
	@Transactional
	@Override
	public Preferencia registrar(DetallePreferenciaDTO preferenciaDTO) {
		preferenciaRepository.save(preferenciaDTO.getPreferencia());
		
		preferenciaDTO.getLstLenguaje().forEach
			(lenguaje->detallePreferenciaRepository.registrar
					(preferenciaDTO.getPreferencia().getId() , lenguaje.getId()));
		
		
		return preferenciaDTO.getPreferencia();
	}
	
}
