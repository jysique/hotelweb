package com.example.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.entities.Programador;
import com.example.model.repository.ProgramadorRepository;
import com.example.service.ProgramadorService;


@Service
public class ProgramadorServiceImpl implements ProgramadorService {

	@Autowired
	private ProgramadorRepository programadorRepository;
	
	@Override
	public Programador registrar(Programador t) {
		return programadorRepository.save(t);
	}

	@Override
	public Programador modificar(Programador t) {
		// TODO Auto-generated method stub
		return programadorRepository.save(t);
	}

	@Override
	public void eliminar(int id) {
		programadorRepository.deleteById(id);
		
	}

	@Override
	public Optional<Programador> listId(int id) {
		// TODO Auto-generated method stub
		return programadorRepository.findById(id);
	}

	@Override
	public List<Programador> listar() {
		// TODO Auto-generated method stub
		return programadorRepository.findAll();
	}

}
